﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleDiaUtil
{
    public static class Classe5DiaUtil
    {
        public static DateTime QuintoDiaUtil(DateTime minhaData)
        {

            var data = new DateTime(minhaData.Year, minhaData.Month, 1);


            switch (data.DayOfWeek)
            {

                case DayOfWeek.Sunday:
                    DateTime nova = data.AddDays(5);
                    return nova;

                case DayOfWeek.Monday:
                    DateTime nova1 = data.AddDays(4);
                    return nova1;

                default:
                    DateTime nova2 = data.AddDays(6);
                    return nova2;
            }

        }
    }
}
