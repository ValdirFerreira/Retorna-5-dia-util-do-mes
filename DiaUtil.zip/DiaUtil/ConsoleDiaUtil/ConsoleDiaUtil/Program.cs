﻿using System;
using System.Globalization;

namespace ConsoleDiaUtil
{
 
    
    
    class Program
    {
        static void Main(string[] args)
        {
            var dataAtual = DateTime.Now;

            var meuQuintoDiaUtil = Classe5DiaUtil.QuintoDiaUtil(dataAtual);

            Console.WriteLine("The current date and time: {0:dd/MM/yy H:mm:ss zzz}",
                       meuQuintoDiaUtil);
            Console.Read();

        }


       
    }
}
